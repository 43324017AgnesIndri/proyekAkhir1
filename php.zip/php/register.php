<?php
include "koneksi.php";
$status = "";
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = mysqli_real_escape_string($conn, $_POST["username"]);
    $password = mysqli_real_escape_string($conn, $_POST["password"]);
    $confirm = mysqli_real_escape_string($conn, $_POST["confirm"]);

    if (empty($username) || empty($password) || empty($confirm)) {
        $status = "error";
        $message = "Semua field wajib diisi.";
    } elseif ($password !== $confirm) {
        $status = "error";
        $message = "Password dan konfirmasi tidak cocok.";
    } else {
        $hashed = password_hash($password, PASSWORD_DEFAULT);
        $query = "INSERT INTO users (username, password) VALUES ('$username', '$hashed')";

        if (mysqli_query($conn, $query)) {
            header("Location: login.php?registered=true");
            exit;
        } else {
            $status = "error";
            $message = "Gagal mendaftarkan user: " . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Register Akun</title>
    <style>
        body {
            background: #f4f4f4;
            font-family: Arial;
            padding: 40px;
        }
        .container {
            background: white;
            padding: 25px;
            max-width: 400px;
            margin: auto;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h2 {
            text-align: center;
            margin-bottom: 25px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label { display: block; margin-bottom: 5px; }
        input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .btn {
            background-color: #4e73df;
            color: white;
            border: none;
            padding: 12px;
            width: 100%;
            border-radius: 4px;
            margin-top: 10px;
            cursor: pointer;
        }
        .btn:hover {
            background-color: #2e59d9;
        }
        .error {
            color: #e74a3b;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Register</h2>

    <?php if ($status == "error"): ?>
        <div class="error"><?php echo $message; ?></div>
    <?php endif; ?>

    <form method="post">
        <div class="form-group">
            <label>Username</label>
            <input type="text" name="username" required>
        </div>
        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" required>
        </div>
        <div class="form-group">
            <label>Konfirmasi Password</label>
            <input type="password" name="confirm" required>
        </div>
        <button type="submit" class="btn">Daftar</button>
    </form>
</div>
</body>
</html>
