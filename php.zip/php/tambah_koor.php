<?php
include "koneksi.php";
session_start();

$status = "";
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = mysqli_real_escape_string($conn, $_POST['nama']);
    $waktu = mysqli_real_escape_string($conn, $_POST['waktu']);
    $user_id = $_SESSION['user_id']; // Pastikan user sudah login

    // Tangani file gambar
    $gambar = $_FILES['gambar']['name'];
    $gambar_tmp = $_FILES['gambar']['tmp_name'];
    $folder_upload = "uploads/Kegiatan/";

    if (!file_exists($folder_upload)) {
        mkdir($folder_upload, 0777, true);
    }

    $target_file = $folder_upload . basename($gambar);

    if (empty($nama) || empty($waktu) || empty($gambar)) {
        $status = "error";
        $message = "Semua field harus diisi.";
    } else {
        if (move_uploaded_file($gambar_tmp, $target_file)) {
            // Simpan ke database
            $query = "INSERT INTO koor (nama, waktu, gambar, user_id) VALUES ('$nama', '$waktu', '$gambar', '$user_id')";
            if (mysqli_query($conn, $query)) {
                header("Location: koor.php?status=success&message=" . urlencode("Data koor berhasil ditambahkan"));
                exit;
            } else {
                $status = "error";
                $message = "Error: " . mysqli_error($conn);
            }
        } else {
            $status = "error";
            $message = "Gagal mengunggah gambar.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Koor</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            background-color: #f8f9fc;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            background: white;
            margin: auto;
            padding: 25px;
            border-radius: 8px;
            box-shadow: 0 0.15rem 1.75rem rgba(0,0,0,0.1);
        }
        h2 {
            margin-bottom: 20px;
            color: #4e73df;
        }
        label {
            display: block;
            margin-top: 15px;
            font-weight: bold;
        }
        input[type="text"], textarea, input[type="file"] {
            width: 100%;
            padding: 12px;
            margin-top: 5px;
            border-radius: 4px;
            border: 1px solid #ccc;
        }
        .btn {
            padding: 12px 24px;
            margin-top: 20px;
            border: none;
            border-radius: 4px;
            color: white;
            cursor: pointer;
            font-size: 16px;
        }
        .btn-primary {
            background-color: #4e73df;
        }
        .btn-danger {
            background-color: #e74a3b;
        }
        .alert {
            padding: 15px;
            margin-top: 15px;
            border-radius: 4px;
            background-color: #f8d7da;
            color: #721c24;
        }
        .back-link {
            display: inline-block;
            margin-top: 10px;
            color: #4e73df;
            text-decoration: none;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Tambah Dokumentasi Koor</h2>

    <?php if ($status == "error"): ?>
        <div class="alert"><?php echo $message; ?></div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data">
        <label for="nama">Nama Acara:</label>
        <textarea name="nama" id="nama" required><?php echo isset($_POST['nama']) ? htmlspecialchars($_POST['nama']) : ''; ?></textarea>

        <label for="waktu">Waktu Pelaksanaan:</label>
        <input type="text" name="waktu" id="waktu" value="<?php echo isset($_POST['waktu']) ? htmlspecialchars($_POST['waktu']) : ''; ?>" required>

        <label for="gambar">Upload Gambar:</label>
        <input type="file" name="gambar" id="gambar" accept="image/*" required>

        <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Simpan</button>
        <a href="koor.php" class="btn btn-danger">Batal</a>
    </form>

    <a href="koor.php" class="back-link"><i class="fas fa-arrow-left"></i> Kembali ke Daftar Koor</a>
</div>
</body>
</html>
