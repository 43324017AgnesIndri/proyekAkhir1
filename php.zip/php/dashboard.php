<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Gereja - Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #3b5998;
            --primary-dark: #2d4373;
            --secondary-color: #f5f7fa;
            --text-color: #333;
            --text-light: #ffffff;
            --border-color: #e3e6f0;
            --accent-color: #4e73df;
            --danger-color: #e74a3b;
            --success-color: #1cc88a;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: var(--secondary-color);
            color: var(--text-color);
            display: flex;
            min-height: 100vh;
        }
        
        .sidebar {
            width: 250px;
            background: linear-gradient(180deg, var(--primary-color) 0%, var(--primary-dark) 100%);
            color: var(--text-light);
            padding-top: 20px;
            position: fixed;
            height: 100vh;
            overflow-y: auto;
        }
        
        .sidebar-header {
            display: flex;
            align-items: center;
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
            margin-bottom: 20px;
        }
        
        .sidebar-header h2 {
            font-size: 22px;
            margin-left: 10px;
            font-weight: 600;
        }
        
        .nav-item {
            width: 100%;
        }
        
        .nav-link {
            display: flex;
            align-items: center;
            padding: 15px 20px;
            color: var(--text-light);
            text-decoration: none;
            transition: all 0.3s;
            margin: 2px 0;
            border-radius: 5px;
        }
        
        .nav-link:hover {
            background-color: rgba(255, 255, 255, 0.1);
        }
        
        .nav-link.active {
            background-color: rgba(255, 255, 255, 0.2);
            font-weight: 600;
        }
        
        .nav-icon {
            width: 20px;
            text-align: center;
            margin-right: 15px;
            font-size: 18px;
        }
        
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 25px;
            background-color: #fff;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
            border-radius: 5px;
            margin-bottom: 25px;
        }
        
        .header h1 {
            font-size: 24px;
            color: var(--primary-dark);
        }
        
        .user-welcome {
            font-size: 16px;
            color: var(--text-color);
        }
        
        .dashboard-cards {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
            gap: 25px;
            margin-bottom: 25px;
        }
        
        .card {
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.1);
            padding: 25px;
        }
        
        .card-header {
            font-size: 18px;
            font-weight: 600;
            color: var(--primary-dark);
            margin-bottom: 15px;
            border-bottom: 1px solid var(--border-color);
            padding-bottom: 10px;
        }
        
        .card-content {
            min-height: 150px;
        }
        
        .stat-card {
            display: flex;
            align-items: center;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.1);
            background-color: #fff;
            margin-bottom: 20px;
        }
        
        .stat-icon {
            font-size: 30px;
            margin-right: 20px;
            padding: 15px;
            border-radius: 50%;
            color: white;
        }
        
        .stat-icon.blue {
            background-color: var(--accent-color);
        }
        
        .stat-icon.red {
            background-color: var(--danger-color);
        }
        
        .stat-icon.green {
            background-color: var(--success-color);
        }
        
        .stat-info h3 {
            font-size: 22px;
            margin-bottom: 5px;
        }
        
        .stat-info p {
            color: #6c757d;
            font-size: 14px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 70px;
            }
            
            .sidebar-header h2, .nav-item span {
                display: none;
            }
            
            .nav-icon {
                margin-right: 0;
            }
            
            .main-content {
                margin-left: 70px;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <i class="fas fa-church fa-2x"></i>
            <h2>Admin Gereja</h2>
        </div>
        
        <nav>
            <div class="nav-item">
                <a href="dashboard.php" class="nav-link active">
                    <i class="fas fa-tachometer-alt nav-icon"></i>
                    <span>Dashboard</span>
                </a>
            </div>
            
            <div class="nav-item">
                <a href="ayat_harian.php" class="nav-link">
                    <i class="fas fa-bible nav-icon"></i>
                    <span>Ayat Harian</span>
                </a>
            </div>
            
            <div class="nav-item">
                <a href="jadwal_ibadah.php" class="nav-link">
                    <i class="fas fa-calendar-alt nav-icon"></i>
                    <span>Jadwal Ibadah</span>
                </a>
            </div>
            
            <div class="nav-item">
                <a href="program_pelayanan.php" class="nav-link">
                    <i class="fas fa-solid fa-folder nav-icon"></i>
                    <span>Program Pelayanan</span>
                </a>
            </div>

            <div class="nav-item">
                <a href="galeri.php" class="nav-link">
                    <i class="fas  fa-light fa-file nav-icon"></i>
                    <span>Galeri</span>
                </a>
            </div>
            
            <div class="nav-item">
                <a href="jemaat.php" class="nav-link">
                    <i class="fas fa-users nav-icon"></i>
                    <span>Jemaat</span>
                </a>
            </div>

            <div class="nav-item">
                <a href="warta_jemaat.php" class="nav-link">
                    <i class="fas fa-solid fa-address-book nav-icon"></i>
                    <span>Warta Jemaat</span>
                </a>
            </div>

            <div class="nav-item">
                <a href="struktur_gereja.php" class="nav-link">
                    <i class="fas fa-solid fa-landmark nav-icon"></i>
                    <span>Struktur Gereja</span>
                </a>
            </div>

            <div class="nav-item">
                <a href="koor.php" class="nav-link">
                    <i class="fas fa-solid fa-folder nav-icon"></i>
                    <span>Koor</span>
                </a>
            </div>

            <div class="nav-item">
                <a href="event.php" class="nav-link">
                    <i class="fas fa-solid fa-folder nav-icon"></i>
                    <span>Event</span>
                </a>
            </div>

            <div class="nav-item">
                <a href="remaja_naposo.php" class="nav-link">
                    <i class="fas fa-solid fa-folder nav-icon"></i>
                    <span>Remaja Naposo</span>
                </a>
            </div>
    
            <div class="nav-item">
                <a href="peta.php" class="nav-link">
                    <i class="fas fa-solid fa-location-dot nav-icon"></i>
                    <span>peta/maps</span>
                </a>
            </div>
            
            
            <div class="nav-item">
                <a href="pengaturan.php" class="nav-link">
                    <i class="fas fa-cog nav-icon"></i>
                    <span>Pengaturan</span>
                </a>
            </div>
            
            <div class="nav-item">
                <a href="logout.php" class="nav-link">
                    <i class="fas fa-sign-out-alt nav-icon"></i>
                    <span>Keluar</span>
                </a>
            </div>
        </nav>
    </div>
    
    <!-- Main Content -->
    <div class="main-content">
        <div class="header">
            <h1>Dashboard</h1>
            <div class="user-welcome">Selamat datang, Admin</div>
        </div>
        
        <div class="row">
            <div class="stat-card">
                <div class="stat-icon blue">
                    <i class="fas fa-users"></i>
                </div>
                <div class="stat-info">
                    <h3>250</h3>
                    <p>Total Jemaat</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon green">
                    <i class="fas fa-calendar-check"></i>
                </div>
                <div class="stat-info">
                    <h3>12</h3>
                    <p>Kegiatan Minggu Ini</p>
                </div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon red">
                    <i class="fas fa-bible"></i>
                </div>
                <div class="stat-info">
                    <h3>365</h3>
                    <p>Ayat Harian</p>
                </div>
            </div>
        </div>
        
        <div class="dashboard-cards">
            <div class="card">
                <div class="card-header">
                    <i class="fas fa-bullhorn"></i>
                    Pengumuman Terbaru
                </div>
                <div class="card-content">
                    <p>Kebaktian Paskah akan diadakan pada tanggal 12 April 2025 pukul 09:00 WIB.</p>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <i class="fas fa-bible"></i>
                    Ayat Harian
                </div>
                <div class="card-content">
                    <p><strong>Amsal 19:21</strong></p>
                    <p>Semua Jalan Kehidupan Adalah Yang Terbaik Dari Tuhan</p>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <i class="fas fa-calendar-alt"></i>
                    Jadwal Ibadah Mendatang
                </div>
                <div class="card-content">
                    <p><strong>Rabu, 09 April 2025</strong> - Doa Malam (19:00)</p>
                    <p><strong>Minggu, 13 April 2025</strong> - Ibadah Minggu (09:00)</p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>